package com.example.bitfit

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ListFragment : Fragment() {

    private val foodList = mutableListOf<FoodItem>()
    private lateinit var adapter: FoodAdapter
    private lateinit var sharedPreferences: SharedPreferences
    private lateinit var gson: Gson

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_list, container, false)

        sharedPreferences = requireActivity().getSharedPreferences("bitfit_prefs", Context.MODE_PRIVATE)
        gson = Gson()

        // Initialize views from the inflated fragment_list layout
        val sleepHoursSeekBar: SeekBar = view.findViewById(R.id.sleepHoursSeekBar)
        val feelingRatingBar: RatingBar = view.findViewById(R.id.feelingRatingBar)
        val sleepHoursProgressTextView: TextView = view.findViewById(R.id.sleepHoursProgressTextView)
        val recyclerView: RecyclerView = view.findViewById(R.id.recyclerView)
        val foodNameEditText: EditText = view.findViewById(R.id.foodNameEditText)
        val caloriesEditText: EditText = view.findViewById(R.id.caloriesEditText)
        val addButton: Button = view.findViewById(R.id.addFoodButton)

        adapter = FoodAdapter(foodList)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        val userDataJson = sharedPreferences.getString("user_data", null)
        if (userDataJson != null) {
            val typeToken = object : TypeToken<List<FoodItem>>() {}.type
            val savedFoodList = gson.fromJson<List<FoodItem>>(userDataJson, typeToken)
            foodList.addAll(savedFoodList)
            adapter.notifyDataSetChanged()
        }

        sleepHoursSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val selectedSleepHours = progress
                sleepHoursProgressTextView.text = "$selectedSleepHours hours"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        feelingRatingBar.setOnRatingBarChangeListener { ratingBar, rating, fromUser -> }

        addButton.setOnClickListener {
            val foodName = foodNameEditText.text.toString()
            val calories = caloriesEditText.text.toString().toIntOrNull()
            val sleepHours = sleepHoursSeekBar.progress
            val feeling = feelingRatingBar.rating

            if (!foodName.isEmpty() && calories != null) {
                val foodItem = FoodItem(foodName, calories, sleepHours, feeling)
                foodList.add(foodItem)
                adapter.notifyDataSetChanged()
                foodNameEditText.text.clear()
                caloriesEditText.text.clear()

                val userDataJson = gson.toJson(foodList)
                sharedPreferences.edit().putString("user_data", userDataJson).apply()

                sleepHoursSeekBar.progress = 0
                feelingRatingBar.rating = 0.0f
            } else {
                Toast.makeText(requireContext(), "Please enter valid data", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }

    // Function to calculate average, maximum, and minimum calories
    private fun calculateCaloriesStatistics(): Triple<Double, Int, Int>? {
        if (foodList.isEmpty()) return null

        var totalCalories = 0.0
        var maxCalories = Int.MIN_VALUE
        var minCalories = Int.MAX_VALUE

        for (foodItem in foodList) {
            val calories = foodItem.calories
            totalCalories += calories

            if (calories > maxCalories) {
                maxCalories = calories
            }

            if (calories < minCalories) {
                minCalories = calories
            }
        }

        val averageCalories = totalCalories / foodList.size
        return Triple(averageCalories, maxCalories, minCalories)
    }
}

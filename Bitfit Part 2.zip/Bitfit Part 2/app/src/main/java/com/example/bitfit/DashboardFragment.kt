package com.example.bitfit

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import android.widget.TextView

class DashboardFragment : Fragment() {

    private lateinit var averageCaloriesTextView: TextView
    private lateinit var maxCaloriesTextView: TextView
    private lateinit var minCaloriesTextView: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_dashboard, container, false)

        // Initialize TextViews
        averageCaloriesTextView = view.findViewById(R.id.averageCaloriesTextView)
        maxCaloriesTextView = view.findViewById(R.id.maxCaloriesTextView)
        minCaloriesTextView = view.findViewById(R.id.minCaloriesTextView)

        return view
    }

    fun updateCaloriesStatistics(averageCalories: Double, maxCalories: Int, minCalories: Int) {
        averageCaloriesTextView.text = "Average Calories: $averageCalories"
        maxCaloriesTextView.text = "Maximum Calories: $maxCalories"
        minCaloriesTextView.text = "Minimum Calories: $minCalories"
    }
}

package com.example.bitfit

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter(private val foodList: List<FoodItem>) : RecyclerView.Adapter<FoodAdapter.FoodViewHolder>() {

    inner class FoodViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val foodNameTextView: TextView = itemView.findViewById(R.id.foodNameTextView)
        val caloriesTextView: TextView = itemView.findViewById(R.id.caloriesTextView)
        val sleepHoursTextView: TextView = itemView.findViewById(R.id.sleepHoursTextView)
        val feelingTextView: TextView = itemView.findViewById(R.id.feelingTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.item_food, parent, false)
        return FoodViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        val currentItem = foodList[position]
        holder.foodNameTextView.text = "${currentItem.foodName}"
        holder.caloriesTextView.text = "${currentItem.calories}"
        holder.sleepHoursTextView.text = "Sleep Hours: ${currentItem.sleepHours}"
        holder.feelingTextView.text = "Feeling: ${currentItem.feeling}"
    }

    override fun getItemCount(): Int {
        return foodList.size
    }
}
